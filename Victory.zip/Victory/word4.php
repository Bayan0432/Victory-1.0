<?php

require_once 'vendor/autoload.php';

$document = new \PhpOffice\PhpWord\TemplateProcessor('МФО.docx');

$uploadDir =  __DIR__;
$outputFile = 'МФО_full.docx';

$uploadFile = $uploadDir . '\\' . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile);

$date = $_POST['date'];
$namemfo = $_POST['namemfo'];
$organ = $_POST['organ'];
$sud = $_POST['sud'];
$name = $_POST['name'];
$problema = $_POST['problema'];
$chtodelal = $_POST['chtodelal'];
$reshenieproblem = $_POST['reshenieproblem'];
$adress = $_POST['adress'];
$tel = $_POST['tel'];
$gmail = $_POST['gmail'];
$file = $_POST['file'];


$document->setValue('date', $date);
$document->setValue('namemfo', $namemfo);
$document->setValue('organ', $organ);
$document->setValue('sud', $sud);
$document->setValue('name', $name);
$document->setValue('problema', $problema);
$document->setValue('chtodelal', $chtodelal);
$document->setValue('reshenieproblem', $reshenieproblem);
$document->setValue('adress', $adress);
$document->setValue('tel', $tel);
$document->setValue('gmail', $gmail);
$document->setImageValue('image', array('path' => $uploadFile, 'width' => 120, 'height' => 120, 'ratio' => false));

$document->saveAs($outputFile);


// Имя скачиваемого файла
$downloadFile = $outputFile;

// Контент-тип означающий скачивание
header("Content-Type: application/octet-stream");

// Размер в байтах
header("Accept-Ranges: bytes");

// Размер файла
header("Content-Length: ".filesize($downloadFile));

// Расположение скачиваемого файла
header("Content-Disposition: attachment; filename=".$downloadFile);  

// Прочитать файл
readfile($downloadFile);


unlink($uploadFile);
unlink($outputFile);