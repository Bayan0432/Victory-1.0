<?php

require_once 'vendor/autoload.php';

$document = new \PhpOffice\PhpWord\TemplateProcessor('Арест со счетов.docx');

$uploadDir =  __DIR__;
$outputFile = 'Адрес со счетов_full.docx';

$uploadFile = $uploadDir . '\\' . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile);

$name = $_POST['name'];
$adress = $_POST['adress'];
$cityindex = $_POST['cityindex'];
$birth = $_POST['birth'];
$namebank = $_POST['namebank'];
$adressbank = $_POST['adressbank'];
$citybankindex = $_POST['citybankindex'];
$yourcompani = $_POST['yourcompani'];
$prichinaaresta = $_POST['prichinaaresta'];
$nomercheta = $_POST['nomercheta'];
$tipcheta = $_POST['tipcheta'];
$datearest = $_POST['datearest'];
$symmaarest = $_POST['symmaarest'];
$reshenieproblemi = $_POST['reshenieproblemi'];
$tel = $_POST['tel'];
$gmail = $_POST['gmail'];
$file = $_POST['file'];


$document->setValue('name', $name);
$document->setValue('adress', $adress);
$document->setValue('cityindex', $cityindex);
$document->setValue('birth', $birth);
$document->setValue('namebank', $namebank);
$document->setValue('adressbank', $adressbank);
$document->setValue('citybankindex', $citybankindex);
$document->setValue('yourcompani', $yourcompani);
$document->setValue('prichinaaresta', $prichinaaresta);
$document->setValue('nomercheta', $nomercheta);
$document->setValue('tipcheta', $tipcheta);
$document->setValue('datearest', $datearest);
$document->setValue('symmaarest', $symmaarest);
$document->setValue('reshenieproblemi', $reshenieproblemi);
$document->setValue('tel', $tel);
$document->setValue('gmail', $gmail);
$document->setImageValue('image', array('path' => $uploadFile, 'width' => 120, 'height' => 120, 'ratio' => false));

$document->saveAs($outputFile);


// Имя скачиваемого файла
$downloadFile = $outputFile;

// Контент-тип означающий скачивание
header("Content-Type: application/octet-stream");

// Размер в байтах
header("Accept-Ranges: bytes");

// Размер файла
header("Content-Length: ".filesize($downloadFile));

// Расположение скачиваемого файла
header("Content-Disposition: attachment; filename=".$downloadFile);  

// Прочитать файл
readfile($downloadFile);


unlink($uploadFile);
unlink($outputFile);